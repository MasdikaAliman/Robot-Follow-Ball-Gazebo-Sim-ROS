#include "esp32-hal.h"
#include <sys/_stdint.h>
#include "esp32-hal-ledc.h"
#include "esp32-hal-gpio.h"
#include "motor.h"



void Motor::testMotor(int type, uint8_t pwm, int dir) {

  switch (type) {
    case motorType::motor1:
      ledcWrite(cha, pwm);
      if (dir) {
        digitalWrite(in1, HIGH);
        digitalWrite(in2, LOW);
      } else {
        digitalWrite(in1, LOW);
        digitalWrite(in2, HIGH);
      }
      break;
    case motorType::motor2:
      digitalWrite(in3, HIGH);
      digitalWrite(in4, LOW);
      ledcWrite(chb, pwm);
      break;

    default:
      break;
  }
}



void Motor::Rotate(int16_t value, int type) {
  switch (type) {
    case motorType::motor1:
     ledcWrite(cha, abs(value));
      // analogWrite(this->ena, value);
      // if (dir == 1) {
      //   digitalWrite(in1, HIGH);
      //   digitalWrite(in2, LOW);
      // } else if (dir == -1) {
      //   digitalWrite(in1, LOW);
      //   digitalWrite(in2, HIGH);
      // } else {
      //   digitalWrite(in1, LOW);
      //   digitalWrite(in2, LOW);
      // }

      if (value > 0) {
        digitalWrite(in1, HIGH);
        digitalWrite(in2, LOW);
      } else if (value < 0) {
        digitalWrite(in1, LOW);
        digitalWrite(in2, HIGH);
      } else {
        digitalWrite(in1, LOW);
        digitalWrite(in2, LOW);
      }

      break;
    case motorType::motor2:
      ledcWrite(chb, abs(value));
      // analogWrite(this->enb, value);
      // if (dir == 1) {
      //   digitalWrite(in3, HIGH);
      //   digitalWrite(in4, LOW);
      // } else if (dir == -1) {
      //   digitalWrite(in3, LOW);
      //   digitalWrite(in4, HIGH);
      // } else {
      //   digitalWrite(in3, LOW);
      //   digitalWrite(in4, LOW);
      // }
      if (value > 0) {
        digitalWrite(in3, HIGH);
        digitalWrite(in4, LOW);
      } else if (value < 0) {
        digitalWrite(in3, LOW);
        digitalWrite(in4, HIGH);
      } else {
        digitalWrite(in3, LOW);
        digitalWrite(in4, LOW);
      }
      break;
    default:
      digitalWrite(in3, LOW);
      digitalWrite(in4, LOW);
      digitalWrite(in3, LOW);
      digitalWrite(in4, LOW);

      break;
  }
}
