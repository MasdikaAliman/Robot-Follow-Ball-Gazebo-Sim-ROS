#include "esp32-hal.h"

float wrap_angle(float angle){
  while(angle > 360)
    angle -= 360;
  while(angle < 0)
    angle += 360;
  
  return angle;
}
void Rotate1(int16_t value, int IN1, int IN2 ,int ENA) {

     analogWrite(ENA, abs(value));
      // analogWrite(this->ena, value);
      // if (dir == 1) {
      //   digitalWrite(in1, HIGH);
      //   digitalWrite(in2, LOW);
      // } else if (dir == -1) {
      //   digitalWrite(in1, LOW);
      //   digitalWrite(in2, HIGH);
      // } else {
      //   digitalWrite(in1, LOW);
      //   digitalWrite(in2, LOW);
      // }

      if (value > 0) {
        digitalWrite(IN1, HIGH);
        digitalWrite(IN2, LOW);
      } else if (value < 0) {
        digitalWrite(IN1, LOW);
        digitalWrite(IN2, HIGH);
      } else {
        digitalWrite(IN1, LOW);
        digitalWrite(IN2, LOW);
      }

  }
void Rotate2(int16_t value, int IN1, int IN2 ,int ENA) {

     analogWrite(ENA, abs(value));
      // analogWrite(this->ena, value);
      // if (dir == 1) {
      //   digitalWrite(in1, HIGH);
      //   digitalWrite(in2, LOW);
      // } else if (dir == -1) {
      //   digitalWrite(in1, LOW);
      //   digitalWrite(in2, HIGH);
      // } else {
      //   digitalWrite(in1, LOW);
      //   digitalWrite(in2, LOW);
      // }

      if (value > 0) {
        digitalWrite(IN1, HIGH);
        digitalWrite(IN2, LOW);
      } else if (value < 0) {
        digitalWrite(IN1, LOW);
        digitalWrite(IN2, HIGH);
      } else {
        digitalWrite(IN1, LOW);
        digitalWrite(IN2, LOW);
      }

  }