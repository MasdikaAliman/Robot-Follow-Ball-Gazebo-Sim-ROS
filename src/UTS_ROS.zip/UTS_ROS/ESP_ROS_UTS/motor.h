#include <sys/_stdint.h>
#include "Arduino.h"

enum motorType {
  motor1,
  motor2
};

class Motor {
public:
  Motor() {}
  Motor(uint8_t IN1, uint8_t IN2, uint8_t IN3, uint8_t IN4, uint8_t ENA, uint8_t ENB, uint8_t CHA, uint8_t CHB)
    : in1(IN1), in2(IN2), in3(IN3), in4(IN4), ena(ENA), enb(ENB), cha(CHA), chb(CHB) {
    pinMode(this->in1, OUTPUT);
    pinMode(this->in2, OUTPUT);
    pinMode(this->ena, OUTPUT);

    pinMode(this->in3, OUTPUT);
    pinMode(this->in4, OUTPUT);
    pinMode(this->enb, OUTPUT);

    digitalWrite(this->in1, LOW);
    digitalWrite(this->in2, LOW);
    digitalWrite(this->in3, LOW);
    digitalWrite(this->in4, LOW);

    ledcSetup(this->cha, this->frequency, this->resolution);
    ledcAttachPin(this->ena, this->cha);

    ledcSetup(this->chb, this->frequency, this->resolution);
    ledcAttachPin(this->enb, this->chb);
  };


  Motor(uint8_t IN1, uint8_t IN2, uint8_t ENA, uint8_t CHA)
    : in1(IN1), in2(IN2), ena(ENA), cha(CHA) {
    pinMode(this->in1, OUTPUT);
    pinMode(this->in2, OUTPUT);
    pinMode(this->ena, OUTPUT);

    digitalWrite(this->in1, LOW);
    digitalWrite(this->in2, LOW);

    ledcSetup(this->cha, this->frequency, this->resolution);
    ledcAttachPin(this->ena, this->cha);
  }

  void Rotate(int16_t value, int type);
  void testMotor(int type, uint8_t pwm, int dir);
private:
  uint8_t in1, in2, in3, in4, ena, enb, cha, chb;
  int resolution = 8;
  int frequency = 255;
};