#include "motion_ros.hpp"
#include "icecream.hpp"
#include "generalFunc.hpp"
motion_ros *motion_ros::instance = 0;

motion_ros *motion_ros::getInstance()
{
    if (instance == 0)
    {
        instance = new motion_ros();
    }
    return instance;
}
void motion_ros::setNode(ros::NodeHandle node)
{
    this->nh = node;
}
motion_ros::motion_ros()
{
    // pwmPub = nh.advertise<motion_pkg::pwmMotor>("speedMotor", 1);
    pwmLeftPub = nh.advertise<std_msgs::Int16>("speedLeft", 1);
    pwmRightPub = nh.advertise<std_msgs::Int16>("speedRight", 1);

    imuSub = nh.subscribe("data_imu", 1, &motion_ros::imuCB, this);
    targetAngleSub = nh.subscribe("targetAngle", 1, &motion_ros::targetAngleCB, this);

    markerPub = nh.advertise<visualization_msgs::Marker>("visualization_marker", 1);

    // Class Init
    pid = new PID(10.0, 180);
}

void motion_ros::imuCB(const sensor_msgs::ImuConstPtr &imuMsg)
{
    // ros::Time

    dataImu = (*imuMsg);
    IC(dataImu.orientation.z);
}

void motion_ros::targetAngleCB(const strategi_pkg::strategyConstPtr &msg)
{
    target = (*msg);
    IC(target.isTargetSuccess, target.targetAngle);
}

bool motion_ros::update()
{
     static int state = 0;
    static int counterState = 0;
    static int moveSpeed = 0;
    static double speed_offset;
    static double x = 0;
    static double y = 0;

    double errorOrientation = testTarget - dataImu.orientation.z;
    if (errorOrientation > 180)
        errorOrientation -= 360;
    if (errorOrientation < -180)
        errorOrientation += 360;

    switch (state)
    {
    case 0:
        if (counterState++ < counterStateMax - 50)
            state = 0;
        else
        {
            if (fabs(errorOrientation) < 3)
            {
           
                state = 1;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        testTarget = target.targetAngle;
        break;

    case 1:
        if (counterState++ < counterStateMax)
        {
 
            state = 1;
            if (moveSpeed < max_speed)
            {
                double velocity_linear = 2;

                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
            
                moveSpeed += 10;
              
            }
        }
        else
        {
            state = 2;
            counterState = 0;
        }
        testTarget = target.targetAngle;
        break;

    case 2:
        if (counterState++ < counterStateMax - 50)
            state = 2;
        else
        {
            if (fabs(errorOrientation) < 3)
            {
           
                state = 3;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        testTarget = 210;
        // testTarget = 90;

        break;
    case 3:
        if (counterState++ < counterStateMax)
        {
            state = 3;
            if (moveSpeed < max_speed )
            {
                double velocity_linear = 1.8;

            

                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
                IC(x);
                moveSpeed += 10;
            }
        }
        else
        {
            state = 4;
            counterState = 0;
        }
        testTarget = 210;
        // testTarget = 90;

        break;
    case 4:
        if (counterState++ < counterStateMax - 50)
            state = 4;
        else
        {
            if (fabs(errorOrientation) < 3)
            {
             
                state = 5;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        testTarget = 70;
        // testTarget = 180;

        break;
    case 5:
        if (counterState++ < counterStateMax )
        {
            state = 5;
            if (moveSpeed < max_speed)
            {
                double velocity_linear = 1.8;

              
                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
                moveSpeed += 10;
            }
        }
        else
        {
            state = 6;
            counterState = 0;
        }
        testTarget = 70;
        // testTarget = 180;

        break;
    case 6:
        if (counterState++ < counterStateMax -50)
            state = 6;
        else
        {

            if (fabs(errorOrientation) < 3)
            {
               
                state = 7;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        testTarget = 280;
        // testTarget = 270;

        break;
    case 7:
        if (counterState++ < counterStateMax)
        {
            state = 7;
            if (moveSpeed < max_speed)
            {
                double velocity_linear = 1.8;

                IC();

                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
                moveSpeed += 10;
            }
        }
        else
        {
            state = 8;
            counterState = 0;
        }
        testTarget = 280;
        // testTarget = 270;

        break;
    case 8:
        if (counterState++ < counterStateMax - 50)
            state = 8;
        else
        {
            if (fabs(errorOrientation) < 3)
            {
             
                state = 9;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        testTarget = 145;
        break;
    case 9:
        if (counterState++ < counterStateMax)
        {
            state = 9;
            if (moveSpeed < max_speed)
            {
                double velocity_linear = 1.8;

             

                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
                moveSpeed += 10;
            }
        }
        else
        {
            state = 10;
            counterState = 0;
        }
        testTarget = 145;
        break;
    default:
        moveSpeed = 0;
        speed_offset = 0;
        break;
    }
 
    pid->setParamRot(1, 0.01, 0.05);


    pid->calc_PIDRot(testTarget * M_PI / 180.0, dataImu.orientation.z * M_PI / 180.0, speed_offset);
    motor outInvers;
    inversKinematic(outInvers, 0, speed_offset);

    pwmMotor outMotor;

    rpsToPwm(outMotor, outInvers.w1, outInvers.w2);

    sendMotor(moveSpeed, moveSpeed, outMotor.left, outMotor.right);

    return true;
}

void motion_ros::mainRobot()
{
    static int state = 0;
    static int counterState = 0;
    static int moveSpeed = 0;
    static double speed_offset;
    static double x = 0;
    static double y = 0;

    double errorOrientation = testTarget - dataImu.orientation.z;
    if (errorOrientation > 180)
        errorOrientation -= 360;
    if (errorOrientation < -180)
        errorOrientation += 360;

    switch (state)
    {
    case 0:
        if (counterState++ < counterStateMax - 50)
            state = 0;
        else
        {
            if (fabs(errorOrientation) < 3)
            {
                IC();
                state = 1;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        testTarget = 0;
        break;

    case 1:
        if (counterState++ < counterStateMax)
        {
            IC();
            state = 1;
            if (moveSpeed < max_speed)
            {
                double velocity_linear = 2;

                IC();

                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
                IC(x);
                moveSpeed += 10;
                IC(moveSpeed);
            }
        }
        else
        {
            state = 2;
            counterState = 0;
        }
        testTarget = 0;
        break;

    case 2:
        if (counterState++ < counterStateMax - 50)
            state = 2;
        else
        {
            if (fabs(errorOrientation) < 3)
            {
                IC();
                state = 3;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        // testTarget = 210;
        testTarget = 90;

        break;
    case 3:
        if (counterState++ < counterStateMax)
        {
            state = 3;
            if (moveSpeed < max_speed )
            {
                double velocity_linear = 1.8;

                IC();

                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
                IC(x);
                moveSpeed += 10;
            }
        }
        else
        {
            state = 4;
            counterState = 0;
        }
        // testTarget = 210;
        testTarget = 90;

        break;
    case 4:
        if (counterState++ < counterStateMax - 50)
            state = 4;
        else
        {
            if (fabs(errorOrientation) < 3)
            {
                IC();
                state = 5;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        // testTarget = 70;
        testTarget = 180;

        break;
    case 5:
        if (counterState++ < counterStateMax )
        {
            state = 5;
            if (moveSpeed < max_speed)
            {
                double velocity_linear = 1.8;

                IC();

                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
                moveSpeed += 10;
            }
        }
        else
        {
            state = 6;
            counterState = 0;
        }
        // testTarget = 70;
        testTarget = 180;

        break;
    case 6:
        if (counterState++ < counterStateMax -50)
            state = 6;
        else
        {

            if (fabs(errorOrientation) < 3)
            {
                IC();
                state = 7;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        // testTarget = 280;
        testTarget = 270;

        break;
    case 7:
        if (counterState++ < counterStateMax)
        {
            state = 7;
            if (moveSpeed < max_speed)
            {
                double velocity_linear = 1.8;

                IC();

                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
                moveSpeed += 10;
            }
        }
        else
        {
            state = 1100;
            counterState = 0;
        }
        // testTarget = 280;
        testTarget = 270;

        break;
    case 8:
        if (counterState++ < counterStateMax - 50)
            state = 8;
        else
        {
            if (fabs(errorOrientation) < 3)
            {
                IC();
                state = 9;
            }
            counterState = 0;
        }
        moveSpeed = 0;
        testTarget = 145;
        break;
    case 9:
        if (counterState++ < counterStateMax)
        {
            state = 9;
            if (moveSpeed < max_speed)
            {
                double velocity_linear = 1.8;

                IC();

                x += velocity_linear * 0.1 * cos(dataImu.orientation.z * M_PI / 180.0);
                y += velocity_linear * 0.1 * sin(dataImu.orientation.z * M_PI / 180.0);
                sendVisual(x, y, 0);
                moveSpeed += 10;
            }
        }
        else
        {
            state = 10;
            counterState = 0;
        }
        testTarget = 145;
        break;
    default:
        moveSpeed = 0;
        speed_offset = 0;
        break;
    }
    IC(state, counterState);

    // if (fabs(errorOrientation) > 30)
    // {
    //     IC();
    //     pid->setParamRot(5, 0, 0.0);
    // }
    // else
    // {
    pid->setParamRot(1, 0.01, 0.05);
    // }

    pid->calc_PIDRot(testTarget * M_PI / 180.0, dataImu.orientation.z * M_PI / 180.0, speed_offset);
    IC(speed_offset, moveSpeed);
    motor outInvers;
    inversKinematic(outInvers, 0, speed_offset);

    IC(outInvers.w1, outInvers.w2);
    pwmMotor outMotor;

    rpsToPwm(outMotor, outInvers.w1, outInvers.w2);
    // rpsToPwm(outMotor, 0.005, 0);
    
    IC(outMotor.left, outMotor.right);

    sendMotor(moveSpeed, moveSpeed, outMotor.left, outMotor.right);
}

double motion_ros::getErrorOrientation()
{
    return (target.targetAngle - dataImu.orientation.z);
}

void motion_ros::setOrientationVisual()
{
    visualData.pose.orientation.x = 0;
    visualData.pose.orientation.y = 0;
    visualData.pose.orientation.z = 0;
    visualData.pose.orientation.w = 1;
}

void motion_ros::setPositionVisual(double x, double y, double z)
{
    visualData.pose.position.x = x;
    visualData.pose.position.y = y;
    visualData.pose.position.z = z;
}

void motion_ros::sendVisual(double x, double y, double z)
{
    visualData.header.frame_id = "map";
    visualData.header.stamp = ros::Time::now();

    visualData.type = visualization_msgs::Marker::LINE_STRIP;
    visualData.action = visualization_msgs::Marker::ADD;
    visualData.scale.x = 0.01;
    visualData.scale.y = 0.05;
    visualData.scale.z = 0.05;

    visualData.color.g = 1.0f;
    visualData.color.a = 1.0;

    setOrientationVisual();

    setPositionVisual(0, 0, 0);

    geometry_msgs::Point point;
    point.x = x;
    point.y = y;
    point.z = 0;

    visualData.points.push_back(point);

    markerPub.publish(visualData);
}

void motion_ros::sendMotor(int pwmLeft, int pwmRight, int speedOffsetLeft, int speedOffsetRight)
{
    std_msgs::Int16 left;
    left.data = pwmLeft + speedOffsetLeft;
    pwmLeftPub.publish(left);

    std_msgs::Int16 right;
    right.data = pwmRight + speedOffsetRight;
    pwmRightPub.publish(right);
}




int motion_ros::constraint(int val, int minimum, int maximum)
{
    if (val > minimum && val < maximum)
        return val;
    else if (val < minimum)
        return minimum;
    else if (val > maximum)
        ;
    return maximum;
}

int motion_ros::changeSpeed(int speed, int increment)
{
    speed += increment;
    if (speed > 240)
        speed = 240;
    else if (speed < -90)
        speed = -90;
    return speed;
}

void motion_ros::rotate()
{
    int leftSpeed = 0, rightSpeed = 0;

    int deltaAngle = round(target.targetAngle - dataImu.orientation.z);
    IC(deltaAngle);
    int targetGyroZ = 0;

    if (abs(deltaAngle) <= 3)
        sendMotor(0, 0);

    else
    {

        if (abs(deltaAngle) > 30)
        {
            targetGyroZ = 80;
        }
        else
        {
            targetGyroZ = 2 * abs(deltaAngle);
        }
        IC(targetGyroZ);
        if (round(targetGyroZ - abs(dataImu.angular_velocity.z)) == 0)
        {
            ; // Do Nothing
        }
        else if (targetGyroZ > abs(dataImu.angular_velocity.z))
        {
            IC();
            leftSpeed = changeSpeed(leftSpeed, 1);
        }
        else
        {
            IC();
            leftSpeed = changeSpeed(leftSpeed, -1);
        }
        IC(leftSpeed);

        rightSpeed = leftSpeed * -1;

        // if (dataImu.orientation.z > target.targetAngle)
        // {
        //     IC("left");
        //     // Left
        //     leftSpeed *= -1;
        //     // rightSpeed *= 1;
        // }
        // else if (dataImu.orientation.z < target.targetAngle)
        // {
        //     IC("right");
        //     // Right
        //     rightSpeed *= -1;
        //     // leftSpeed  *= 1;
        // }
        IC(leftSpeed, rightSpeed);
        sendMotor(leftSpeed, rightSpeed);
    }
}