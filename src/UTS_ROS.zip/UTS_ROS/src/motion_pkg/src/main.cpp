#include "iostream"
#include "motion_ros.hpp"
int main(int argc, char **argv)
{
    ros::init(argc,argv, "motion_ros");

    ros::NodeHandle n;

    motion_ros::getInstance()->setNode(n);
    ROS_INFO("START PUBLISH .............");
    ros::Rate r(30);
        
    while (ros::ok())
    {
    
        motion_ros::getInstance()->update();
   
        ros::spinOnce();
        r.sleep();
    }
    
    return 0;
}
