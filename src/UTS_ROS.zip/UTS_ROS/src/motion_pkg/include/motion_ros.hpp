#ifndef MOTION_ROS_H
#define MOTION_ROS_H
#include "ros/ros.h"
#include "motion_pkg/pwmMotor.h"
#include "std_msgs/Int16.h"
#include "std_msgs/Float64.h"
#include "strategi_pkg/strategy.h"
#include "sensor_msgs/Imu.h"
#include "visualization_msgs/Marker.h"
#include "geometry_msgs/Point.h"
#include "PID.h"

#define base_speed 120

class motion_ros
{
public:
    motion_ros();
    ~motion_ros() {}

    static motion_ros *getInstance();

    void setNode(ros::NodeHandle node);
    void sendMotor(int pwmLeft, int pwmRight , int speedOffsetLeft = 0, int speedOffsetRight = 0);
    void imuCB(const sensor_msgs::ImuConstPtr &imuMsg);
    void targetAngleCB(const strategi_pkg::strategyConstPtr &msg);
    bool update();
    double getErrorOrientation();

    void setOrientationVisual();
    void setPositionVisual(double x, double y, double z);
    void sendVisual(double x, double y, double z);

    void mainRobot();

    int changeSpeed(int speed, int increment);
    void rotate();

    int constraint(int val, int minimum , int maximum);

  

    // void printData()
    // {
    //     ROS_INFO_STREAM(dataImu.orientation.z);
    // }

private:
    static motion_ros *instance;
    ros::NodeHandle nh;
    ros::Publisher pwmLeftPub;
    ros::Publisher pwmRightPub;
    ros::Publisher markerPub;
    ros::Subscriber imuSub;
    ros::Subscriber targetAngleSub;

    visualization_msgs::Marker visualData;

    // Data Subscriber
    sensor_msgs::Imu dataImu;
    // std_msgs::Float64 targetAngle;
    strategi_pkg::strategy target;

    int counterStateMax = 100;
    int max_speed = 150;
    double testTarget = 0;

    //Class
    PID *pid;
};



#endif
