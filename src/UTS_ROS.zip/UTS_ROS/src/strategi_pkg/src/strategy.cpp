#include "iostream"
#include "ros/ros.h"
#include "vector"
#include "strategi_pkg/strategy.h"
#include "sensor_msgs/Imu.h"
#include "icecream.hpp"

std::vector<double> listAngle = {0.0, 90.0, 180.0, 270.0};

sensor_msgs::Imu imuData;
strategi_pkg::strategy strategy_pub;
void imuCB(const sensor_msgs::ImuConstPtr &msg)
{
    imuData = *(msg);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "strategy");

    ros::NodeHandle n;

    ros::Subscriber imuSub;
    imuSub = n.subscribe<sensor_msgs::Imu>("data_imu", 1, imuCB);

    ros::Publisher targetAnglePub;
    targetAnglePub = n.advertise<strategi_pkg::strategy>("targetAngle", 1);

    ROS_INFO("START PUBLISH .............");
    ros::Rate r(30);
    // ros::AsyncSpinner spinner(2);
    // spinner.start();

    bool stopRobot = false;
    int index = 0;
    static int counter;
    int counterMaximum = 300;

    while (ros::ok())
    {
        IC();
        double error = listAngle.at(index) - imuData.orientation.z;

        if (error > 180)
            error -= 360;
        if (error < -180)
            error += 360;

        IC(error);
        strategy_pub.isTargetSuccess = false;
        strategy_pub.isStop = stopRobot;
        if (fabs(error) < 10)
        {
            
            strategy_pub.isTargetSuccess = true;
            IC(counter);
            if (counter > counterMaximum && !stopRobot)
            {
                index++;
                counter = 0;
            }

            counter++;
        }
        IC(index);
        if ((index > listAngle.size() - 1))
        {
            IC();
            strategy_pub.isTargetSuccess = false;
            strategy_pub.isStop = true;
            index = listAngle.size() - 1;
            stopRobot = true;
        }

        strategy_pub.targetAngle = listAngle.at(index);

        IC(strategy_pub.targetAngle, strategy_pub.isTargetSuccess, strategy_pub.isStop);
        targetAnglePub.publish(strategy_pub);
        ros::spinOnce();
        r.sleep();
    }

    return 0;
}
